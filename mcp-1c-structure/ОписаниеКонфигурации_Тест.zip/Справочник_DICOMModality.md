﻿# Справочник: DICOMModality (DICOM Modality)

## Реквизиты


